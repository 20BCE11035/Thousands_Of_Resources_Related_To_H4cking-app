# Cybersecurity GPTs and Colab Notebooks
- [Awesome Cybersecurity GPT Agents ](https://github.com/fr0gger/Awesome-GPT-Agents): A comprehensive list of GPT agents focused on cybersecurity (offensive and defensive).
- [Awesome List of AI-related Google Collab Notebooks](https://github.com/amrzv/awesome-colab-notebooks): A great collection of colab notebooks collection for ML experiments
